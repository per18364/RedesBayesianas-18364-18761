from redes import estaDescrita
from redes import factores
from redes import algoritmo_de_enumeracion
from redes import redCompacta
from redes import crearred
