# lab2_18364_18761

## En las funciones solo se debe ingresar una string:

### EJ: redes.crearred('c->r->w<-s<-c')
